# 🎸 Penny Lane - Telegram Group ID Bot

Named after the "band aid" (not groupie!) from Almost Famous, Penny Lane is a privacy-focused Telegram bot that helps group administrators get their group IDs quickly and securely.

## ✨ Features

- **RAM-only storage** - No data ever touches disk
- **5-minute memory** - All info automatically expires 
- **Admin verification** - Only group admins can request IDs
- **Private delivery** - Group IDs sent via DM, never in group chat
- **Cross-platform** - Works on any OS through Telegram

## 🚀 For Bot Users (Your Friends)

Using Penny Lane is dead simple - no installations needed!

### Step 1: Start Privately
1. Find the bot: `@YourPennyLaneBot` (replace with actual username)
2. Send `/start` in a private chat
3. You're now registered!

### Step 2: Get Group ID
1. Add the bot as an **administrator** to your group
2. Send `/start` in the group chat
3. Check your private messages - the group ID will be there!
4. Copy the ID and use it however you need

### Commands
- `/start` - Register privately or get group ID
- `/help` - Show help information  
- `/status` - View bot status (private chat only)

### Privacy Promise
- Your info is kept in memory for **maximum 5 minutes**
- No databases, no log files, no permanent storage
- Bot restart = instant memory wipe
- Only you receive your group IDs via private message

## 🔧 For Bot Hosters (Setup Instructions)

### Prerequisites
- Python 3.9+
- A Telegram Bot Token from [@BotFather](https://t.me/BotFather)
- A server/computer that stays online

### Quick Setup

1. **Clone and setup**:
```bash
git clone <your-repo>
cd penny_lane
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

2. **Set your bot token**:
```bash
export PENNY_BOT_TOKEN="your_bot_token_here"
```

3. **Run the bot**:
```bash
python penny_lane.py
```

### Production Deployment

For 24/7 operation, use a process manager:

**systemd example** (`/etc/systemd/system/penny-lane.service`):
```ini
[Unit]
Description=Penny Lane Telegram Bot
After=network.target

[Service]
Type=simple
User=penny
WorkingDirectory=/home/penny/penny_lane
Environment=PENNY_BOT_TOKEN=your_token_here
ExecStart=/home/penny/penny_lane/venv/bin/python penny_lane.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Enable with:
```bash
sudo systemctl enable --now penny-lane
```

### Cloud Deployment Options

**Free Tier Options (Perfect for Penny Lane):**

🆓 **Railway** (Recommended)
- $0/month for 512MB RAM, 500 hours/month
- Easy GitHub integration
- Set env vars in dashboard
- Deploy: Connect repo → Set `PENNY_BOT_TOKEN` → Deploy

🆓 **Render**  
- Free tier: 512MB RAM, sleeps after 15min idle
- Wakes up automatically when used
- Great for low-traffic bots

🆓 **Fly.io**
- Free allowance: 160GB-hours/month (plenty for a bot)
- Always-on, no sleeping
- More technical but very reliable

**Paid Options ($5-10/month):**
- **DigitalOcean App Platform**: $5/month, always-on
- **Heroku**: $7/month basic dyno
- **VPS** (Linode, DigitalOcean): $5/month, full control

**Quick Railway Deploy:**
```bash
# Install Railway CLI
npm install -g @railway/cli
# Or: curl -fsSL https://railway.app/install.sh | sh

# Deploy
railway login
railway new penny-lane
railway add
railway up
# Set PENNY_BOT_TOKEN in Railway dashboard
```

Set `PENNY_BOT_TOKEN` as an environment variable in your platform's dashboard.

## 🔒 Security Features

- **No persistent storage** - Everything lives in RAM only
- **Automatic expiry** - Data purged after 5 minutes
- **Admin verification** - Only group admins can trigger ID requests
- **Private delivery** - IDs never appear in group chats
- **Minimal logging** - No sensitive data in logs

## 🛠️ Customization

Want to modify the behavior? Key variables in `penny_lane.py`:

- `TTL = 300` - How long to remember group IDs (seconds)
- Modify messages in the command handlers
- Add additional commands if needed

## 📝 License

This project is open source. Feel free to modify and share!

## 🎵 Why "Penny Lane"?

*"She was a band aid. The term 'groupie' was an insult. These women were there out of pure love of music."* - Almost Famous

Just like Penny Lane helped connect people to the music they loved, this bot helps connect admins to the group info they need - simply, privately, and without judgment.

---

**Questions?** Open an issue or reach out to the bot hoster!
